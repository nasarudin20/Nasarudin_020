package model;

import Koneksi.Cinnector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminDAO {
    public boolean  validateLogin(Strring username, String )
    
}
