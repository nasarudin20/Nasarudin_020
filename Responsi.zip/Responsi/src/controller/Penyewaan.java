package controller;

import model.Penyewaan;
import model.Mobil;
import model.PenyewaanDAO;
import model.MobilDAO;
import View.InputDataPage;

import javax.swing.*;
import java.util.List;

public class PenyewaanController{
    private InputDataPage viewPanel;
    private PenyewaanDAO penyewaanDAO;
    private MobilDAO mobilDAO;
    
    public PenyewaanController(InputDataPage viwPanel, PenyewaanDAO penyewaanDAO, MobilDAO mobilDAO){
        this.viewPanel = viewPanel;
        this.penyewaanDAO = penyewaanDAO;
        this.mobilDAO = mobilDAO;
        
        initController();
    }
    
    private void initController(){
    
}
}
